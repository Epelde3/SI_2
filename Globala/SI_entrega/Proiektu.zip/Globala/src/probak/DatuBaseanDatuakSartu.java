package probak;

import dataAccess.DataAccess;

public class DatuBaseanDatuakSartu {

	
	public static void main(String[]args) {
		DataAccess db = new DataAccess();
		
		
		db.datuakSartu();;
		
	}
}
